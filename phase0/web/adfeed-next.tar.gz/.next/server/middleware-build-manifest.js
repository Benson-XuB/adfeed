globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Cxn05Ft2KXacFtGtOegHZ/_buildManifest.js",
    "static/Cxn05Ft2KXacFtGtOegHZ/_ssgManifest.js",
    "static/Cxn05Ft2KXacFtGtOegHZ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yiddnbtmgj46.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/3hdj40qmts5sf.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-3i-ystnex-6gs.js"
  ]
};
