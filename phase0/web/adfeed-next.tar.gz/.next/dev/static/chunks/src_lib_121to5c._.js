(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "activateSubscription",
    ()=>activateSubscription,
    "api",
    ()=>api,
    "downloadFeed",
    ()=>downloadFeed,
    "getBillingPlans",
    ()=>getBillingPlans,
    "getGoogleUrl",
    ()=>getGoogleUrl,
    "getJob",
    ()=>getJob,
    "getJobResults",
    ()=>getJobResults,
    "getMe",
    ()=>getMe,
    "googleCallback",
    ()=>googleCallback,
    "listFeeds",
    ()=>listFeeds,
    "listJobs",
    ()=>listJobs,
    "processJob",
    ()=>processJob,
    "requestMagicLink",
    ()=>requestMagicLink,
    "uploadFile",
    ()=>uploadFile,
    "verifyMagicLink",
    ()=>verifyMagicLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_BASE = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
async function api(path, options = {}) {
    const { token, ...fetchOpts } = options;
    const headers = {
        ...fetchOpts.headers || {}
    };
    if (!(fetchOpts.body instanceof FormData)) {
        headers["Content-Type"] = "application/json";
    }
    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }
    const res = await fetch(`${API_BASE}${path}`, {
        ...fetchOpts,
        headers,
        credentials: "include"
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({
                detail: res.statusText
            }));
        throw new Error(err.detail || `HTTP ${res.status}`);
    }
    if (res.headers.get("content-type")?.includes("application/xml")) {
        return res.text();
    }
    return res.json();
}
async function getMe(token) {
    return api("/api/auth/me", {
        token
    });
}
async function getGoogleUrl() {
    const { url } = await api("/api/auth/google/url");
    return url;
}
async function googleCallback(code) {
    return api("/api/auth/google/callback", {
        method: "POST",
        body: JSON.stringify({
            code
        })
    });
}
async function requestMagicLink(email) {
    await api("/api/auth/magic-link", {
        method: "POST",
        body: JSON.stringify({
            email
        })
    });
}
async function verifyMagicLink(token) {
    return api(`/api/auth/magic-link/verify?token=${encodeURIComponent(token)}`);
}
async function uploadFile(file, countries, token, onProgress) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("countries", JSON.stringify(countries));
    // 用 XMLHttpRequest 替代 fetch 以获得上传进度
    return new Promise((resolve, reject)=>{
        const xhr = new XMLHttpRequest();
        xhr.open("POST", `${API_BASE}/api/upload`);
        xhr.setRequestHeader("Authorization", `Bearer ${token}`);
        xhr.withCredentials = true;
        // 大文件上传超时：10 分钟
        xhr.timeout = 10 * 60 * 1000;
        xhr.upload.addEventListener("progress", (e)=>{
            if (e.lengthComputable && onProgress) {
                onProgress(Math.round(e.loaded / e.total * 100));
            }
        });
        xhr.addEventListener("load", ()=>{
            try {
                const data = JSON.parse(xhr.responseText);
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(data);
                } else {
                    reject(new Error(data.detail || `HTTP ${xhr.status}`));
                }
            } catch  {
                reject(new Error("Invalid response"));
            }
        });
        xhr.addEventListener("error", ()=>reject(new Error("Upload failed")));
        xhr.addEventListener("timeout", ()=>reject(new Error("Upload timed out — file too large or network too slow. Please try again.")));
        xhr.send(fd);
    });
}
async function listJobs(token) {
    return api("/api/jobs", {
        token
    });
}
async function getJob(id, token) {
    return api(`/api/jobs/${id}`, {
        token
    });
}
async function processJob(id, token) {
    await api(`/api/jobs/${id}/process`, {
        method: "POST",
        token
    });
}
async function getJobResults(id, token) {
    return api(`/api/jobs/${id}/results`, {
        token
    });
}
async function listFeeds(token) {
    return api("/api/feeds", {
        token
    });
}
async function downloadFeed(country, token) {
    return api(`/api/feeds/${country}`, {
        token
    });
}
async function getBillingPlans(token) {
    return api("/api/billing/plans", {
        token
    });
}
async function activateSubscription(paypalSubscriptionId, paypalPlanId, token) {
    await api("/api/billing/activate", {
        method: "POST",
        token,
        body: JSON.stringify({
            paypal_subscription_id: paypalSubscriptionId,
            paypal_plan_id: paypalPlanId
        })
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    user: null,
    token: null,
    loading: true,
    setAuth: ()=>{},
    logout: ()=>{},
    refresh: async ()=>{}
});
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [token, setToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const setAuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[setAuth]": (t, u)=>{
            setToken(t);
            setUser(u);
            localStorage.setItem("adfeed_token", t);
        }
    }["AuthProvider.useCallback[setAuth]"], []);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[logout]": ()=>{
            setToken(null);
            setUser(null);
            localStorage.removeItem("adfeed_token");
        }
    }["AuthProvider.useCallback[logout]"], []);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[refresh]": async ()=>{
            const t = localStorage.getItem("adfeed_token");
            if (!t) {
                setLoading(false);
                return;
            }
            try {
                const u = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMe"])(t);
                setToken(t);
                setUser(u);
            } catch  {
                localStorage.removeItem("adfeed_token");
            } finally{
                setLoading(false);
            }
        }
    }["AuthProvider.useCallback[refresh]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            refresh();
        }
    }["AuthProvider.useEffect"], [
        refresh
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            token,
            loading,
            setAuth,
            logout,
            refresh
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/auth.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "jKDvfP6+Z7Mc0HwBnfcQv8oC5MI=");
_c = AuthProvider;
function useAuth() {
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
}
_s1(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_lib_121to5c._.js.map