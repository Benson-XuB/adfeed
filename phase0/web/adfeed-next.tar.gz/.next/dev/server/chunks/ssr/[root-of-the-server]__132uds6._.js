module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/lib/api.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "activateSubscription",
    ()=>activateSubscription,
    "api",
    ()=>api,
    "downloadFeed",
    ()=>downloadFeed,
    "getBillingPlans",
    ()=>getBillingPlans,
    "getGoogleUrl",
    ()=>getGoogleUrl,
    "getJob",
    ()=>getJob,
    "getJobResults",
    ()=>getJobResults,
    "getMe",
    ()=>getMe,
    "googleCallback",
    ()=>googleCallback,
    "listFeeds",
    ()=>listFeeds,
    "listJobs",
    ()=>listJobs,
    "processJob",
    ()=>processJob,
    "requestMagicLink",
    ()=>requestMagicLink,
    "uploadFile",
    ()=>uploadFile,
    "verifyMagicLink",
    ()=>verifyMagicLink
]);
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
async function api(path, options = {}) {
    const { token, ...fetchOpts } = options;
    const headers = {
        ...fetchOpts.headers || {}
    };
    if (!(fetchOpts.body instanceof FormData)) {
        headers["Content-Type"] = "application/json";
    }
    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }
    const res = await fetch(`${API_BASE}${path}`, {
        ...fetchOpts,
        headers,
        credentials: "include"
    });
    if (!res.ok) {
        const err = await res.json().catch(()=>({
                detail: res.statusText
            }));
        throw new Error(err.detail || `HTTP ${res.status}`);
    }
    if (res.headers.get("content-type")?.includes("application/xml")) {
        return res.text();
    }
    return res.json();
}
async function getMe(token) {
    return api("/api/auth/me", {
        token
    });
}
async function getGoogleUrl() {
    const { url } = await api("/api/auth/google/url");
    return url;
}
async function googleCallback(code) {
    return api("/api/auth/google/callback", {
        method: "POST",
        body: JSON.stringify({
            code
        })
    });
}
async function requestMagicLink(email) {
    await api("/api/auth/magic-link", {
        method: "POST",
        body: JSON.stringify({
            email
        })
    });
}
async function verifyMagicLink(token) {
    return api(`/api/auth/magic-link/verify?token=${encodeURIComponent(token)}`);
}
async function uploadFile(file, countries, token, onProgress) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("countries", JSON.stringify(countries));
    // 用 XMLHttpRequest 替代 fetch 以获得上传进度
    return new Promise((resolve, reject)=>{
        const xhr = new XMLHttpRequest();
        xhr.open("POST", `${API_BASE}/api/upload`);
        xhr.setRequestHeader("Authorization", `Bearer ${token}`);
        xhr.withCredentials = true;
        // 大文件上传超时：10 分钟
        xhr.timeout = 10 * 60 * 1000;
        xhr.upload.addEventListener("progress", (e)=>{
            if (e.lengthComputable && onProgress) {
                onProgress(Math.round(e.loaded / e.total * 100));
            }
        });
        xhr.addEventListener("load", ()=>{
            try {
                const data = JSON.parse(xhr.responseText);
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(data);
                } else {
                    reject(new Error(data.detail || `HTTP ${xhr.status}`));
                }
            } catch  {
                reject(new Error("Invalid response"));
            }
        });
        xhr.addEventListener("error", ()=>reject(new Error("Upload failed")));
        xhr.addEventListener("timeout", ()=>reject(new Error("Upload timed out — file too large or network too slow. Please try again.")));
        xhr.send(fd);
    });
}
async function listJobs(token) {
    return api("/api/jobs", {
        token
    });
}
async function getJob(id, token) {
    return api(`/api/jobs/${id}`, {
        token
    });
}
async function processJob(id, token) {
    await api(`/api/jobs/${id}/process`, {
        method: "POST",
        token
    });
}
async function getJobResults(id, token) {
    return api(`/api/jobs/${id}/results`, {
        token
    });
}
async function listFeeds(token) {
    return api("/api/feeds", {
        token
    });
}
async function downloadFeed(country, token) {
    return api(`/api/feeds/${country}`, {
        token
    });
}
async function getBillingPlans(token) {
    return api("/api/billing/plans", {
        token
    });
}
async function activateSubscription(paypalSubscriptionId, paypalPlanId, token) {
    await api("/api/billing/activate", {
        method: "POST",
        token,
        body: JSON.stringify({
            paypal_subscription_id: paypalSubscriptionId,
            paypal_plan_id: paypalPlanId
        })
    });
}
}),
"[project]/src/lib/auth.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({
    user: null,
    token: null,
    loading: true,
    setAuth: ()=>{},
    logout: ()=>{},
    refresh: async ()=>{}
});
function AuthProvider({ children }) {
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [token, setToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const setAuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((t, u)=>{
        setToken(t);
        setUser(u);
        localStorage.setItem("adfeed_token", t);
    }, []);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        setToken(null);
        setUser(null);
        localStorage.removeItem("adfeed_token");
    }, []);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        const t = localStorage.getItem("adfeed_token");
        if (!t) {
            setLoading(false);
            return;
        }
        try {
            const u = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getMe"])(t);
            setToken(t);
            setUser(u);
        } catch  {
            localStorage.removeItem("adfeed_token");
        } finally{
            setLoading(false);
        }
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        refresh();
    }, [
        refresh
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            token,
            loading,
            setAuth,
            logout,
            refresh
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/auth.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
function useAuth() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
}
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/dynamic-access-async-storage.external.js [external] (next/dist/server/app-render/dynamic-access-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/dynamic-access-async-storage.external.js", () => require("next/dist/server/app-render/dynamic-access-async-storage.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__132uds6._.js.map