module.exports=[37405,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_upload_page_actions_0gijsas.js.map