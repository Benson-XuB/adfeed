module.exports=[65441,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_feeds_page_actions_19i_bgx.js.map