module.exports=[8122,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_upgrade_page_actions_1ouqvtn.js.map