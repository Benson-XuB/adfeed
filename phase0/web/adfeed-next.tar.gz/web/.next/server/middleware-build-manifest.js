globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/_wU0cy4jqgT516svLvdTg/_buildManifest.js",
    "static/_wU0cy4jqgT516svLvdTg/_ssgManifest.js",
    "static/_wU0cy4jqgT516svLvdTg/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yiddnbtmgj46.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/3hdj40qmts5sf.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-3i-ystnex-6gs.js"
  ]
};
